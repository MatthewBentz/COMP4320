// ----------------------------------------------
// Matthew Bentz, Chase Hopkins, James Haberstroh

import java.io.*;
import java.net.*;
import java.util.*;

class UDPClient {

    private static double lossProb = 1;
    private static double damageProb = 1;
    private static InetAddress serverIP = null;
    private static final int serverPort = 9876;
    private final static int PACKET_SIZE = 1024;
    private static final BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws Exception {

        // -----------------------
        // Client local variables.

        int sequenceNum;
        int damagedChecksum = 0;
        byte[] receiveData = new byte[PACKET_SIZE + 1];
        Stack<Integer> sequenceNumStack = new Stack<>();
        DatagramSocket clientSocket = new DatagramSocket();

        // ------------------------------------
        // Send HTTP GET request to the server.

        byte[] sendData = promptUser();
        DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverIP, serverPort);
        clientSocket.send(sendPacket);

        // -----------------------------------
        // Parse received packets from server.

        int count = 0;
        ArrayList<Integer> lostPackets = new ArrayList<>();
        ArrayList<Integer> damagedPackets = new ArrayList<>();
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

        while (true) {
            clientSocket.receive(receivePacket);

            // -------------------
            // Check for nullByte.

            if (receivePacket.getData()[0] == (byte) '\0')
                break;

            //if (count != 0 && count <= 2) {

                //byte[] temp = Arrays.copyOf(receivePacket.getData(), PACKET_SIZE);
                //System.out.print(new String(temp));

            //} else if (count >= 3) {

                // ---------------------------
                // Get packet sequence number.

                sequenceNum = receivePacket.getData()[PACKET_SIZE - 1];
                sequenceNumStack.push(sequenceNum);

                // ------------------
                // Print packet data.

                byte[] temp = Arrays.copyOf(receivePacket.getData(), PACKET_SIZE - 1);
                System.out.print(new String(temp));

                // --------------------------
                // Calculate packet checksum.

                byte[] uncorrupted = receivePacket.getData();
                int calculatedChecksum = calculateChecksum(uncorrupted);

                // ----------------------------
                // Damage packets with Gremlin.

                byte[] damagedPacket = Gremlin(damageProb, lossProb, uncorrupted);

                if (damagedPacket != null) {
                    damagedChecksum = calculateChecksum(damagedPacket);

                    if (calculatedChecksum != damagedChecksum)
                        damagedPackets.add(sequenceNum);

                } else {
                    lostPackets.add(sequenceNum);
                }

                // -----------------------------------
                // Send NACK for lost/damaged packets.

                if (damagedPacket == null || calculatedChecksum != damagedChecksum) {
                    sendData = ("NACK " + sequenceNum).getBytes();
                    clientSocket.send(new DatagramPacket(sendData, sendData.length, serverIP, serverPort));
                }

                // ----------------------------
                // Send ACK for intact packets.

                else {
                    sendData = ("ACK " + sequenceNum).getBytes();
                    clientSocket.send(new DatagramPacket(sendData, sendData.length, serverIP, serverPort));
                }
            //}

            count++;
        }

        // -------------------------------------
        // Print out received packet statistics.

        System.out.println("\n\n---------------------");
        System.out.println("Damaged packets: \t" + damagedPackets.size());
        if (!damagedPackets.isEmpty()) {
            System.out.println(damagedPackets + "\n");
        }

        System.out.println("Lost packets: \t\t" + lostPackets.size());
        if (!lostPackets.isEmpty()) {
            System.out.println(lostPackets + "\n");
        }

        System.out.println("All packets: \t\t" + sequenceNumStack);
        System.out.println("---------------------");

        // --------
        // Cleanup.

        userIn.close();
        clientSocket.close();
    }

    public static byte[] Gremlin(double userDamageProb, double userLossProb, byte[] packetData) {

        Random rand = new Random();
        double randDamageProb = rand.nextDouble();

        // ----------------------------------
        // Find probability packet gets lost.

        if (randDamageProb < userLossProb) {
            return null;
        }

        // -------------------------------------
        // Find probability packet gets damaged.

        if (randDamageProb < userLossProb + userDamageProb) {

            // -----------------------------------------------
            // Find probability of how many bytes are damaged.

            double flipProb = rand.nextDouble();
            int bytesToChange;

            if (flipProb <= 0.5) {
                bytesToChange = 1;
            } else if (flipProb <= 0.8) {
                bytesToChange = 2;
            } else {
                bytesToChange = 3;
            }

            for (int i = 0; i < bytesToChange; i++) {
                int byteNum = rand.nextInt(packetData.length);
                packetData[byteNum] = (byte) ~packetData[byteNum];
            }
        }

        return packetData;
    }

    public static int calculateChecksum(byte[] packetData) {

        // --------------------------
        // Add all bytes from packet.

        int checksum = 0;
        for (byte packetDatum : packetData) {
            checksum += packetDatum;
        }

        return checksum;
    }

    private static byte[] promptUser() throws IOException {

        byte[] sendData;

        // --------------------------
        // Prompt user for server IP.

        do {
            try {
                System.out.println("Please enter the server's IP:");
                serverIP = InetAddress.getByName(userIn.readLine());
                break;
            } catch (UnknownHostException e) {
                System.out.println("Cannot find the server, please try again.");
            }
        } while (true);

        // ------------------------------------
        // Prompt user for Gremlin probability.

        do {
            try {
                System.out.println("\nPlease enter packet damage probability:");
                damageProb = Double.parseDouble(userIn.readLine());

                System.out.println("\nPlease enter packet loss probability:");
                lossProb = Double.parseDouble(userIn.readLine());

                if (damageProb + lossProb > 1) {
                    System.out.println("Please re-enter probabilities < 1.");
                }
            } catch (Exception e) {
                System.out.println("Please re-enter valid double probabilities.");
                System.out.println(e.getMessage());
            }
        } while (damageProb + lossProb >= 1);

        // --------------------------
        // Prompt user for file name.

        String fileName;
        do {
            System.out.println("\nPlease enter a file name for your GET request:");
            fileName = userIn.readLine();
            sendData = ("GET " + fileName + " HTTP/1.0").getBytes();
        } while (fileName.length() <= 0);

        return sendData;
    }
}