// ----------------------------------------------
// Matthew Bentz, Chase Hopkins, James Haberstroh

import java.io.*;
import java.lang.reflect.Array;
import java.net.*;
import java.util.*;
import java.nio.file.*;

class UDPServer {

    private static final int serverPort = 9876;
    private final static int PACKET_SIZE = 1024;

    public static void main(String[] args) throws Exception {

        // -----------------------
        // Server local variables.

        String nullByte = "\0";
        int sequenceNumber = 0;
        final int WINDOW_SIZE = 8;
        List<byte[]> packets = new ArrayList<>();
        byte[] receiveData = new byte[PACKET_SIZE];
        DatagramSocket serverSocket = new DatagramSocket(serverPort);
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

        // ------------------------------
        // Continuously process requests.

        while (true) {
            serverSocket.receive(receivePacket);

            // ----------------------------
            // Retrieve client IP and port.

            InetAddress clientIP = receivePacket.getAddress();
            int clientPort = receivePacket.getPort();

            // -----------------------------------
            // Extract file name from GET request.

            String request = new String(receivePacket.getData());
            String fileName = request.split(" ")[1];
            System.out.println("File requested: " + fileName + "\n");
            printOutFileContent(fileName);

            // -------------------------------------
            // Segment response to packets and send.

            ArrayList<DatagramPacket> packetsToSend = segmentFileToPackets(fileName, clientIP, clientPort);

            for (int i = 0; i < packetsToSend.size(); i++) {
                System.out.println("Sequence Number: " + i);
                serverSocket.send(packetsToSend.get(i));
            }

            // -----------------------------------
            // Check client response for ACK/NACK.

            // DISCLAIMER: In the middle of refactoring this code.
            // First zip sent is working, however it is currently 11:40 and this project is due.
            // Please refer to the client/server out text.

            int startIndex = 0;
            int endIndex = 7;
            ArrayList<Integer> packetsToResend = new ArrayList<>();
            boolean Sending = true;

            // sending packets, waiting for acks and nacks and re-sending packets.

            while (Sending) {
                byte[] temp = packetsToSend.get(startIndex);

                // create a datagram with data to send, length, IP addr, clientPort
                DatagramPacket sendPacket = new DatagramPacket(temp, temp.length, clientIP, clientPort);
                // send datagram to the server
                serverSocket.send(sendPacket);

                // receiving ack or nack
                DatagramPacket ackOrNackPacket = new DatagramPacket(receiveData, receiveData.length);
                serverSocket.receive(ackOrNackPacket);

                String X = new String(ackOrNackPacket.getData());
                String[] input = X.split(" ");
                String Y = input[1];
                int Z = Character.getNumericValue(Y.charAt(0));
                // System.out.println("sequence Number: " + Z);
                String ackOrNack = input[0];
                int nackIndex = Character.getNumericValue(Y.charAt(0));

                // checkif it is ack or nack
                if (ackOrNack.compareTo("NACK") == 0) {
                    packetsToResend.add(nackIndex);
                    startIndex++;
                } else {
                    startIndex++;
                    endIndex++;
                }

                // exit the while loop at the last packet
                if (startIndex == packets.size()) {
                    break;
                }
            }

            // resending NACK packages
            for (int X : packetsToResend) {
                byte[] temp = packets.get(X);

                // create a datagram with data to send, length, IP addr, clientPort
                DatagramPacket sendPacket = new DatagramPacket(temp, temp.length, clientIP, clientPort);
                // send datagram to the server
                serverSocket.send(sendPacket);
            }

            // Sending the last nullbyte packet
            byte[] nullBytePacket = nullByte.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(nullBytePacket, nullBytePacket.length, clientIP, clientPort);
            serverSocket.send(sendPacket);
            System.out.println("\nThe following have been resent due to NACK:\n" + packetsToResend);

            System.out.println(
                    "----------------------------------\nnullByte packet sent.\n----------------------------------");

            System.exit(0);
        }
    }

    private static void printOutFileContent(String fileName) {
        try {

            BufferedReader fileBuffer = new BufferedReader(new FileReader(fileName));
            String nextLine = fileBuffer.readLine();

            while (nextLine != null) {
                System.out.println(nextLine);
                nextLine = fileBuffer.readLine();
            }

            fileBuffer.close();

        } catch (Exception e) {
            System.out.println("Error reading file.");
            System.exit(1);
        }
        System.out.println();
    }

    private static ArrayList<DatagramPacket> segmentFileToPackets(String fileName, InetAddress clientIP, int clientPort) throws IOException {

        // ----------------------------
        // Cast response as byte array.

        byte[] file = Files.readAllBytes(Paths.get(fileName));

        byte[] header = ("HTTP/1.0 200 Document Follows\r\n"
                        + "Content-Type: text/plain\r\n"
                        + "Content-Length: " + file.length + "\r\n"
                        + "\r\n").getBytes();

        byte[] response = new byte[header.length + file.length];
        System.arraycopy(header, 0, response, 0, header.length);
        System.arraycopy(file, 0, response, header.length, file.length);

        // --------------------------------
        // Segment packets into 1024 bytes.

        ArrayList<DatagramPacket> packetsToSend = new ArrayList<>();

        for (int i = 0; i <= response.length / PACKET_SIZE; i++) {

            // ---------------------
            // Set first 1023 bytes.

            byte[] data = Arrays.copyOfRange(response, (i*PACKET_SIZE), (i*PACKET_SIZE) + PACKET_SIZE - 1);

            // --------------------------------------
            // Allocate byte 1024 as sequence number.

            byte[] packet = Arrays.copyOf(data, PACKET_SIZE);
            packet[PACKET_SIZE - 1] = (byte) i;

            packetsToSend.add(new DatagramPacket(packet, packet.length, clientIP, clientPort));
        }

        // ----------------------------------------------
        // Handle last packet that's not 1024 bytes long.

        int lastByteIndex = (response.length / PACKET_SIZE ) * PACKET_SIZE;
        byte[] data = Arrays.copyOfRange(response, lastByteIndex, response.length);
        byte[] packet = Arrays.copyOf(data, PACKET_SIZE);
        packetsToSend.add(new DatagramPacket(packet, packet.length, clientIP, clientPort));

        return packetsToSend;
    }
}